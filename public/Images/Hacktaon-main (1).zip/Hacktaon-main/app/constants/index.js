export const TeachersideBarItems = [
    {
      title: "LEARN",
      href: "/learn",
    },
  ];