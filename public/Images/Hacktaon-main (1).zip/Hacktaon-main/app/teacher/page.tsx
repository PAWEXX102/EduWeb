import SideBar from "../components/sidebar";

export default function Home() {
  return <main className=" text-white flex w-full h-full">
    <SideBar />
    Teacher
  </main>;
}
