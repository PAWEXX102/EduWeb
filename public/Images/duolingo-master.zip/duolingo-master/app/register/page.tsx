"use client";
import { useState } from "react";

import Image from "next/image";

export default function Register() {
  const [isActive, setIsActive] = useState<boolean>(false);
  return (
    <div className="flex flex-col px-20 items-center w-full py-5 text-center bg-white">
      <nav className="w-full">
        <h1 className="text-4xl font-extrabold text-lime-500">duolingo 2</h1>
      </nav>
      <div className=" w-full h-svh mt-16 flex flex-wrap gap-10 content-start">
        <div
          onClick={() => setIsActive(!isActive)}
          className={` border-2 relative hover:scale-105 border-[#e2e8f0] transition-all active:scale-95 cursor-pointer border-b-[4px] active:border-b-3 w-[22rem] h-[14rem] rounded-xl flex flex-col gap-y-5 items-center text-center justify-center`}
        >
          <Image
            src="/Flags/PL.svg"
            alt="Poland"
            width={110}
            height={100}
            className=" rounded-md shadow-md mb-3"
          />
          <h2 className="text-xl font-extrabold absolute bottom-6">Polish</h2>
          {isActive && (
            <div className=" p-1 rounded-lg absolute text-center items-center top-2 bg-lime-500 right-2">
              <Image
                src="/Images/check.png"
                alt="Check"
                width={20}
                height={20}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
