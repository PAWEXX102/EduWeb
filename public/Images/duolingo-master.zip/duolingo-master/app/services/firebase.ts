import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

export const firebaseConfig = {
  apiKey: "AIzaSyC1FbpfCLUb8sl6Z6xq5TsdSgEt5vlu1ws",
  authDomain: "duolingo-30612.firebaseapp.com",
  projectId: "duolingo-30612",
  storageBucket: "duolingo-30612.appspot.com",
  messagingSenderId: "134950124783",
  appId: "1:134950124783:web:567975919412c2d4316f1a",
  measurementId: "G-PRDBEW6CG3",
};

export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);
