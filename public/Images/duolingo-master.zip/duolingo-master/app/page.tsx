"use client";
import { MyButton } from "./components/buttons";
import { useState } from "react";
import Login from "./components/login";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function Home() {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const router = useRouter();
  console.log(isOpen);
  return (
    <main className="flex flex-col items-center justify-between w-full py-5 text-center text-white bg-white ">
      <nav className="w-full ">
        <h1 className="text-4xl font-extrabold text-lime-500">duolingo 2</h1>
      </nav>
      <div className="flex flex-col items-center my-auto ">
        <p className=" text-4xl font-extrabold mb-14 text-zinc-600 max-w-[35rem] px-10">
          A free, fun and effective way to learn a language!
        </p>
        <div className="flex-col absolute sm:flex sm:static bottom-0 px-5 w-full items-center max-w-[25rem]">
          <MyButton color="active" className="w-full ">
            <Link href="/register">GET STARTED</Link>
          </MyButton>
          <MyButton
            onClick={() => router.push("/?isLogin=true")}
            color="primary"
            className="w-full mt-3 mb-5 "
          >
            I ALREADY HAVE AN ACCOUNT
          </MyButton>
        </div>
      </div>
    </main>
  );
}
