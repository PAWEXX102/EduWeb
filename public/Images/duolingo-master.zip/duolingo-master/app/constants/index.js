export const sideBarItems = [
  {
    title: "LEARN",
    href: "/learn",
  },
  {
    title: "LEADERBOARD",
    href: "/leaderboard",
  },
  {
    title: "AI",
    href: "/ai",
  },
  {
    title: "PROFILE",
    href: "/profile",
  }
];
