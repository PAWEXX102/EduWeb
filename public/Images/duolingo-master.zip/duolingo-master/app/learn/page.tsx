import SideBar from "../components/sideBar";

export default function Learn() {
  return (
    <div className=" flex text-white w-full">
      <SideBar />
      Learn
    </div>
  );
}
