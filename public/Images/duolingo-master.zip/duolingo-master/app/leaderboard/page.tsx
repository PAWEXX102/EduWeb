"use client";

import React, { useState, useEffect } from "react";

export default function Leaderboard() {
  const [response, setResponse] = useState<string | undefined>(undefined);
  const [loading, setLoading] = useState(true);

  
  return (
    <div className="flex gap-x-3 text-white overflow-auto w-full">
      {response ? response : "No response"}
    </div>
  );
}
